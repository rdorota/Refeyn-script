# ISCAM Analysis 
A Python package to analyse iSCAM data.

# Howto use
Have a look into notebooks.

# Cite as follows:
Jachowski, T.J. and Kharlamova, M.A. (2020). ISCAM Analysis: A Python package to plot and analyse iSCAM data. GitHub repository: https://github.com/tobiasjj/iscam_analysis
